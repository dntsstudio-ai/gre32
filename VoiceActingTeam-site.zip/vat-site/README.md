# Voice Acting Team — Official Website

Сайт студии дубляжа Voice Acting Team.

## Структура проекта

```
/
├── index.html          # Главная страница
├── css/
│   └── style.css       # Стили (фиолетово-бирюзовая палитра)
├── js/
│   ├── app.js          # Главный модуль, инициализация Firebase
│   ├── core.js         # Утилиты: навигация, тосты, модалки
│   ├── auth.js         # Авторизация
│   ├── releases.js     # Релизы и плеер
│   ├── player.js       # SWS Player v3
│   ├── comments.js     # Комментарии
│   ├── team.js         # Команда студии
│   ├── users.js        # Профили пользователей
│   ├── achievements.js # Достижения
│   ├── dubin.js        # DUB-in платформа
│   ├── order.js        # Заказ озвучки
│   └── playlists.js    # Плейлисты
├── config/
│   └── config.js       # Firebase конфиг + константы
├── img/
│   └── logo.jpg        # Логотип VAT
├── firestore.rules     # Правила безопасности Firebase
└── .github/
    └── workflows/
        └── deploy.yml  # GitHub Pages автодеплой
```

## Деплой на GitHub Pages

1. Загрузи содержимое папки в репозиторий GitHub
2. Перейди: Settings → Pages → Source: GitHub Actions
3. При каждом пуше в `main` сайт обновится автоматически

## Firebase Rules

Скопируй содержимое `firestore.rules` в:
Firebase Console → Firestore Database → Rules

## Социальные сети

- Telegram: https://t.me/VoiceActingTeam1
- ВКонтакте: https://vk.com/voiceactingteam1
- YouTube: https://youtube.com/@voiceactingteam1
- TikTok: https://www.tiktok.com/@voice.acting.team8
- Boosty: https://boosty.to/voiceactingteam
- Twitch: https://vattchelovekizvuchat.com/twich
